using UnityEngine;
using UnityEngine.SceneManagement;

public class Door2 : MonoBehaviour
{
    public GameObject E_Door2;
    public bool isTrigger;
    public int pintu;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //CHEKC APAKAH MENCET NYA UDH E DAN DI TMPT YG BENAR?
        if (Input.GetKeyDown(KeyCode.E) && isTrigger && !Overall.instance.Puzzle2)
        {
            //SIMPAN DATA TERAKHIR KALI
            PlayerPrefs.SetFloat("PlayerX", transform.position.x);
            PlayerPrefs.SetFloat("PlayerY", transform.position.y);
            PlayerPrefs.SetInt("Kembali", 1);
            PlayerPrefs.Save();


            //LOAD KE DALEM RUANGAN
            if (pintu == 1)
            {
                SceneManager.LoadScene("Gedung1");
            }
            else if (pintu == 2)
            {
                SceneManager.LoadScene("Gedung2");
            }
            else if (pintu == 3)
            {
                SceneManager.LoadScene("Gedung3");
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!Overall.instance.Puzzle2)
        {
            E_Door2.SetActive(true);
            isTrigger = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (E_Door2 != null)
        {
            E_Door2.SetActive(false);
            isTrigger = false;
        }
    }

}
