using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayTrigger : MonoBehaviour
{

    public GameObject PanelButton;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnMouseDown()
    {

        SceneManager.LoadScene("SampleScene");
    }

    private void OnMouseOver()
    {
        PanelButton.SetActive(true);
    }

    private void OnMouseExit()
    {
        PanelButton.SetActive(false);
    }
}
