using TMPro;
using UnityEngine;
using UnityEngine.UI;
using static System.Net.Mime.MediaTypeNames;

public class Computer : MonoBehaviour
{
    public GameObject ComputerUI;
    public GameObject interactUI;
    public TMP_InputField inputField;
    public GameObject TandaSeru;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        inputField.characterLimit = 6;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void enterButton(TMP_InputField text)
    {
        string hasil = text.text;
        if (hasil.Trim().ToUpper() == "IRGL25")
        {
            ComputerUI.SetActive(false);
            Overall.instance.IncreaseScore(500);
            Overall.instance.Puzzle2 = true;
            interactUI.SetActive(false);
            TandaSeru.SetActive(false);
        }
        else
        {
            text.text = "******";
        }
    }
    public void exitButton()
    {
        ComputerUI.SetActive(false);
        inputField.text = "******";
    }

    public void onSelect()
    {
        inputField.text = "";
    }
}
