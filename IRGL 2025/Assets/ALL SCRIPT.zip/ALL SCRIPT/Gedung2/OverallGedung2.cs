using UnityEngine;

public class OverallGedung2 : MonoBehaviour
{
    public GameObject interactUI;
    public GameObject UI;

    public int jenis = 0;

    public bool isTrigger = false;
    public bool isComputerUIActive = false;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && isTrigger && !Overall.instance.Puzzle2)
        {
            if (UI != null)
            {
                UI.SetActive(true);
            }
        }
        if (Input.GetMouseButtonDown(0) && isTrigger && jenis == 0 && !Overall.instance.Puzzle2)
        {
            UI.SetActive(false);
        }
        if (!isTrigger && jenis == 0)
        {
            UI.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (interactUI != null && !Overall.instance.Puzzle2)
        {
            isTrigger = true;
            interactUI.SetActive(true);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (interactUI != null)
        {
            isTrigger = false;
            interactUI.SetActive(false);
        }
    }
}
