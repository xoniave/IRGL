using TMPro;
using UnityEngine;
using System.Collections;

public class NpcG2 : MonoBehaviour
{
    public GameObject Talk;
    public GameObject DialogueUi;
    public TextMeshProUGUI TextMeshProUGUI;
    public bool isTrigger = false;
    public string Text = "";
    public bool isFinish = true;
    public Coroutine Coroutine;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // ==================== PUZZLE 1
        if (Input.GetKeyDown(KeyCode.E) && isTrigger && !Overall.instance.Puzzle2) // ini kalo pencet E
        {

            if (isFinish) // hanya bisa jika text udh selesai ketik
            {
                DialogueUi.SetActive(true);
                Coroutine = StartCoroutine(ShowText()); // terus jalanin animasi text 1/1
                isFinish = false;
            }
        }
        else if(Input.GetKeyDown(KeyCode.E) && isTrigger && Overall.instance.Puzzle2)
        {
            Text = "Puzzle Done, GO search another mission";
            if (isFinish) // hanya bisa jika text udh selesai ketik
            {
                DialogueUi.SetActive(true);
                Coroutine = StartCoroutine(ShowText()); // terus jalanin animasi text 1/1
                isFinish = false;
            }
        }

        if (Input.GetMouseButtonDown(0))// kalo click mouse kiri
        {
            if (!isFinish)// text belum sleesai berarti
            {
                if (Coroutine != null)
                {
                    StopCoroutine(Coroutine);// memberhwentikan fungsi coroutine
                }

                TextMeshProUGUI.text = Text; // langsnug keluari text
                isFinish = true;
            }
            else // jika pencet mouse tapi text udh selesai
            {
                DialogueUi.SetActive(false); // ilangin ui nya
                isFinish = true;
            }
        }

        //KELUAR DRI TRIGGER ILANGIN TEXT
        if (!isTrigger)
        {
            DialogueUi.SetActive(false);
            if (Coroutine != null)
            {
                StopCoroutine(Coroutine);// memberhwentikan fungsi coroutine
            }
            TextMeshProUGUI.text = "";
            isFinish = true;
        }

    }

    //coriutine harus pake IEnum dengan yield return 
    IEnumerator ShowText()
    {
        TextMeshProUGUI.text = ""; // kosongkan teks dulu

        for (int i = 0; i < Text.Length; i++)
        {
            TextMeshProUGUI.text += Text[i];
            yield return new WaitForSeconds(0.03f); // kecepatan ngetik, bisa kamu ubah
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        isTrigger = true;
        Talk.SetActive(true);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        isTrigger = false;
        Talk.SetActive(false);
    }
}
