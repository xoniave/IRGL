using UnityEngine;

public class brankasTrigger : MonoBehaviour
{

    public GameObject BrankasE;
    public GameObject ui;
    public bool isTrigger = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(isTrigger && Input.GetKeyDown(KeyCode.E) && !Overall.instance.Puzzle1)
        {
            ui.SetActive(true);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(!Overall.instance.Puzzle1)
        {
            isTrigger = true;
            BrankasE.SetActive(true);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if(BrankasE != null)
        {
            isTrigger = false;
            BrankasE.SetActive(false);
        }
    }
}
