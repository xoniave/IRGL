using System.Collections;
using TMPro;
using UnityEngine;

public class OverallGedung1 : MonoBehaviour
{


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }


    //BRANKAS LOGIC

    public GameObject uiBrankas;
    public GameObject BrankasE;
    public string Jawaban;

    public TextMeshProUGUI inputText1;
    public TextMeshProUGUI inputText2;
    public TextMeshProUGUI inputText3;
    public TextMeshProUGUI inputText4;
    public TextMeshProUGUI inputText5;

    public GameObject minWaktuUi;

    public void CloseUiBrankas()
    {
        uiBrankas.SetActive(false);
    }

    public void EnterBrankas()
    {

        //Check jawaban
        int Angka = int.Parse(inputText1.text + inputText2.text + inputText3.text + inputText4.text + inputText5.text);
        int answer = int.Parse(Jawaban);
        if (Angka == answer)
        {
            Debug.Log("True");
            CloseUiBrankas();
            Overall.instance.IncreaseScore(500);
            Overall.instance.Puzzle1 = true;// FLAG PUZZLE 1 DONEB
            BrankasE.SetActive(false);
        }
        else
        {
            //MIN JAM
            Overall.instance.MinSecond();

            minWaktuUi.SetActive(true);

            inputText1.text = "0";
            inputText2.text = "0";
            inputText3.text = "0";
            inputText4.text = "0";
            inputText5.text = "0";

            StartCoroutine(DelayWaktu());
        }
    }

    public IEnumerator DelayWaktu()
    {
        yield return new WaitForSeconds(1f);

        minWaktuUi.SetActive(false);
    }

    public void IncreaseBrankas(TextMeshProUGUI inputText)
    {
        int Angka = int.Parse(inputText.text);

        if(Angka == 0)
        {
            inputText.text = "1";
        }
        else
        {
            inputText.text = "0";
        }
    }
}
